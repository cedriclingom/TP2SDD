/*-----------------------------------------------------------*/
/*                                                           */
/*      INFORMATIONS COMPLEMENTAIRE SUR LE TP DES PILES      */
/*                                                           */
/*-----------------------------------------------------------*/





1) La taille de la pile qui sert au jeux de test sur la fonction qui test les procédures et fonctions de pile est définit comme constante dans le fichier pile.h.

2) La taille du tableau qui sert à contenir les données de permutations lors de l'exécution de TrucRecursive et TrucItérative est définit comme constante dans le fichier truc.h.

3) Lorsque vous lancerai le make pour la première fois, elle fera la compilation, créera l'exécutable et lancera l'exécution.


4) Sachant que la compilation et la création de l'exécutable sera déjà fait pour lancer exécutable fait la commande: "make execute".

5) Pour lancer valgrind, fait la commande: "make valgrind". 
